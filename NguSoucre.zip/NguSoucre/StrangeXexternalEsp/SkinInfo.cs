namespace StrangeXexternalEsp;

public class SkinInfo
{
	public string Name;

	public uint SkinID;

	public uint Color;
}
