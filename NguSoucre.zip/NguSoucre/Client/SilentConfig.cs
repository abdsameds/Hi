namespace Client;

public static class SilentConfig
{
	public static float HeadRate = 0.5f;

	public static float ChestRate = 0.5f;

	public static float MaxRandomOffset = 0.04f;

	public static float MaxZOffset = 0.003f;

	public static float BulletSpeed = 350f;

	public static float PredictionMultiplier = 1f;
}
