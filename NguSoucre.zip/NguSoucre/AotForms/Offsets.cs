namespace AotForms
{
    internal static class Offsets
    {

        internal static uint Il2Cpp = 0x0;
        internal static ulong Il2CppBase;
        // --- Gốc pointer chain ---
        internal static uint InitBase                    = 0xA342EFC;
internal static uint StaticClass                 = 0x5C;
internal static uint CurrentMatch                = 0x50;
internal static uint MatchStatus                 = 0x8C;
internal static uint LocalPlayer                 = 0x94;
internal static uint DictionaryEntities          = 0x68;
internal static uint CurrentObserver             = 0xB4;
internal static uint ObserverPlayer              = 0x28;

// --- Player ---
internal static uint Player_IsDead               = 0x50;
internal static uint Player_Name                 = 0x31C;
internal static uint Player_Data                 = 0x48;
internal static uint Player_ShadowBase           = 0x1A60;
internal static uint XPose                       = 0x78;
internal static uint LocalPlayerAttributes       = 0x500;
internal static uint NoReload                    = 0xC1;

// --- Avatar ---
internal static uint AvatarManager               = 0x504;
internal static uint Avatar                      = 0xA8;
internal static uint Avatar_IsVisible            = 0x95;
internal static uint Avatar_Data                 = 0x14;
internal static uint Avatar_Data_IsTeam          = 0x59;

// --- Camera ---
internal static uint FollowCamera                = 0x494;
internal static uint Camera                      = 0x18;
internal static uint Camera_Intptr               = 0x8;
internal static uint MainCameraTransform         = 0x28C;
internal static uint ViewMatrix                  = 0xE8;
internal static uint AimRotation                 = 0x400;

// --- Weapon ---
internal static uint Weapon                      = 0x434;
internal static uint WeaponData                  = 0x58;
internal static uint WeaponName                  = 0x38;
internal static uint WeaponRecoil                = 0xC;
internal static uint Weapon_ItemId               = 0x494;

// --- Aim ---
internal static uint sAim1                       = 0x440;
internal static uint sAim2                       = 0x454;
internal static uint sAim3                       = 0x38;
internal static uint sAim4                       = 0x2C;
internal static uint HeadCoilder                 = 0x4E8;
internal static uint MainCollider                = 0x54;
internal static uint porul                       = 0x54;

// --- Loot ---
internal static uint LevelObjectManager          = 0x60;
internal static uint LevelObjectManagerAlt       = 0x64;
internal static uint LootPickupList              = 0xDC;
internal static uint LootPickupListAlt           = 0xC4;
internal static uint LootTransformComponent      = 0x3C;

// --- Skin map (Dictionary<uint,uint> trong IL2CPP) ---
internal static uint WeaponSkinMap               = 0x1A80;
internal static uint SkinMap_kArr                = 0x8;
internal static uint SkinMap_vArr                = 0xC;
internal static uint SkinMap_Size                = 0x10;
internal static uint SkinArray_Capacity          = 0xC;
internal static uint SkinArray_Base              = 0x10;
}
    }