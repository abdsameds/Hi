namespace AotForms;

public enum TminhAuthStatus
{
	Idle,
	Verifying,
	Authenticated,
	Failed
}
