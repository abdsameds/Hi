using System.Numerics;

namespace AotForms;

public struct GroundLootEntry
{
	public uint ItemId;

	public Vector3 Position;

	public string Name;

	public float Distance;
}
