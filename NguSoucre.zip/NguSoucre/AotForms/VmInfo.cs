namespace AotForms;

public struct VmInfo
{
	public ulong Pvm;

	public ulong Pvcpu0;

	public uint CpuCount;

	public ulong ReadCounter;

	public ulong RegionSize;
}
