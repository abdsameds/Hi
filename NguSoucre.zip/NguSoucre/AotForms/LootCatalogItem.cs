namespace AotForms;

public class LootCatalogItem
{
	public uint Id;

	public string Name;

	public int Category;
}
