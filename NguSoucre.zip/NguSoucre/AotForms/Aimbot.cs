namespace AotForms;

internal static class Aimbot
{
	internal static void Start()
	{
		AimbotLegit.Start();
	}

	internal static void Stop()
	{
		AimbotLegit.Stop();
	}
}
