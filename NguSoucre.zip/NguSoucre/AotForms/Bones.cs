namespace AotForms;

internal enum Bones : uint
{
	Head = 1180u,
	Breast = 1188u,
	Root = 1200u,
	hip = Breast,
	LeftHand = 1224u,
	RightHand = 1176u,
	Eye = 976u,
	LeftShoulder = 1232u,
	RightShoulder = 1236u,
	LeftFoot = 1216u,
	RightFoot = 1220u,
	LeftLeg = Head,
	RightLeg = 1184u,
	rightankle = 1212u,
	leftankle = 1208u,
	Spine = Breast,
	Hip = Breast,
	LeftWrist = LeftHand,
	RightWrist = RightHand
}
