namespace AotForms;

public struct TranslationResult
{
	public ulong GuestPhysical;

	public ulong HostPointer;
}
